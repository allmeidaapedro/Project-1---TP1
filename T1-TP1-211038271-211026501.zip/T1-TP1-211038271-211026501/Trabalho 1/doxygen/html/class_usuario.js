var class_usuario =
[
    [ "getMatricula", "class_usuario.html#a3d42a081e5adb2383b63229531da7503", null ],
    [ "getNome", "class_usuario.html#a712640c003aa66605846627f2c90db60", null ],
    [ "getSenha", "class_usuario.html#a8f78d3949b3a9492d0aa0a197860a972", null ],
    [ "setMatricula", "class_usuario.html#a13f706c131738017a7d8e30563722c19", null ],
    [ "setNome", "class_usuario.html#a67580c333ab37fda94a3cb7c52121ef2", null ],
    [ "setSenha", "class_usuario.html#a52d502676a951f13722e22af20c9cea7", null ]
];