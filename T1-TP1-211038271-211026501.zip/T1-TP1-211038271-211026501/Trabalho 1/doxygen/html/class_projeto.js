var class_projeto =
[
    [ "getCodigo", "class_projeto.html#a5d9c3bb6177e5c62176347461bd620a3", null ],
    [ "getDescricao", "class_projeto.html#a600487ea6215134c7035454139cfd348", null ],
    [ "getNome", "class_projeto.html#ae5301064d20f054eca74fe0aad4bc3da", null ],
    [ "setCodigo", "class_projeto.html#a7474ab46180b997142a9497104dee87f", null ],
    [ "setDescricao", "class_projeto.html#aa5b9d3c4894850e326b3c3e28a9670d7", null ],
    [ "setNome", "class_projeto.html#ac33a12a558a5ced45b614aaedbb38c26", null ]
];