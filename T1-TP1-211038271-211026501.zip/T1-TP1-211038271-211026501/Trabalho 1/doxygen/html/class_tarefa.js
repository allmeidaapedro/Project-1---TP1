var class_tarefa =
[
    [ "getCodigo", "class_tarefa.html#aa54be3da2eb40e46d74bdb0dfc5f5a0d", null ],
    [ "getDisciplina", "class_tarefa.html#ae8a24081bb538a65a23eb388219f5325", null ],
    [ "getInicio", "class_tarefa.html#a842c1b965f8c6b48c69b04a32e742367", null ],
    [ "getNome", "class_tarefa.html#a5484e09e36a1cbd845f768acb92150f1", null ],
    [ "getTermino", "class_tarefa.html#ae0b637455d55b09635754621515a65a4", null ],
    [ "setCodigo", "class_tarefa.html#a05757b34adec051e78b5fd53bf8faf18", null ],
    [ "setDisciplina", "class_tarefa.html#ac1e472d1970ab114757027c8dda117be", null ],
    [ "setInicio", "class_tarefa.html#a969072cd445a94df8154316a1f9d66ac", null ],
    [ "setNome", "class_tarefa.html#a17647ba6228393044a4d6c92ce4d21a9", null ],
    [ "setTermino", "class_tarefa.html#a855d6b359620ac2bc05c88d66d8d91d6", null ]
];