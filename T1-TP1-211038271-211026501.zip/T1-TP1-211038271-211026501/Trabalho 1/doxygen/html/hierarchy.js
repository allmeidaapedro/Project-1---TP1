var hierarchy =
[
    [ "Dominio", "class_dominio.html", [
      [ "Codigo", "class_codigo.html", null ],
      [ "Data", "class_data.html", null ],
      [ "Disciplina", "class_disciplina.html", null ],
      [ "Matricula", "class_matricula.html", null ],
      [ "Nome", "class_nome.html", null ],
      [ "Senha", "class_senha.html", null ],
      [ "Texto", "class_texto.html", null ]
    ] ],
    [ "Projeto", "class_projeto.html", null ],
    [ "Tarefa", "class_tarefa.html", null ],
    [ "TUCodigo", "class_t_u_codigo.html", null ],
    [ "TUData", "class_t_u_data.html", null ],
    [ "TUDisciplina", "class_t_u_disciplina.html", null ],
    [ "TUMatricula", "class_t_u_matricula.html", null ],
    [ "TUNome", "class_t_u_nome.html", null ],
    [ "TUProjeto", "class_t_u_projeto.html", null ],
    [ "TUSenha", "class_t_u_senha.html", null ],
    [ "TUTarefa", "class_t_u_tarefa.html", null ],
    [ "TUTexto", "class_t_u_texto.html", null ],
    [ "TUUsuario", "class_t_u_usuario.html", null ],
    [ "Usuario", "class_usuario.html", null ]
];