var searchData=
[
  ['validar_0',['validar',['../class_dominio.html#a778fa2ec4c361cc2d368f6fa01727be8',1,'Dominio']]]
];
