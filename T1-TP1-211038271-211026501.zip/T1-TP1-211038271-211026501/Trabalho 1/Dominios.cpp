#include "Dominios.h"
#include <algorithm>
#include <string>
#include <vector>
#include <sstream>
#include <iostream> //ambos so por enquanto


void Dominio::setValor(string valor){
    validar(valor);
    this->valor = valor;
}


void Matricula::validar(string valor){

    if(valor.size() != 8){
        throw invalid_argument("Argumento invalido.");
    }

    for(int i=0; valor[i]!='\0'; i++){
        if(i <= 3){
            if(isupper(valor[i]) == 0){
                throw invalid_argument("Argumento invalido.");
            }
        }
        else{
            if(isdigit(valor[i]) == 0){
                throw invalid_argument("Argumento invalido.");
            }
        }
    }
}


void Senha::validar(string valor){

    if(valor.size() != 6){
        throw invalid_argument("Argumento invalido.");
    }

    sort(valor.begin(), valor.end());

    //verificar se tem duplicados
    for(int i=0; i<valor.size(); i++){
        for(int j=i+1; j<valor.size(); j++){
            if(valor[i]==valor[j]){
                throw invalid_argument("Argumento invalido.");
            }
        }
    }

    //verificar se atende maiusculas e numeros e contar pelo menos 2
    int maiusculas= 0;
    int numeros = 0;

    for(int i=0; valor[i]!='\0'; i++){
        if(isupper(valor[i]) == 0 && isdigit(valor[i]) == 0){
            throw invalid_argument("Argumento invalido.");
        }
        else{
            if(isupper(valor[i])){
                maiusculas++;
            }
            else if(isdigit(valor[i])){
                numeros++;
            }
        }
    }
    if(maiusculas < 2 || numeros < 2){
        throw invalid_argument("Argumento invalido.");
    }
}

void Texto::validar(string valor){


    //verificar tamanho (entre 10 e 40)
    if(valor.size() < 10 || valor.size() > 40){
        throw invalid_argument("Argumento invalido.");
    }

    char pontuacao[] = {'.', ',', ';', '?', '!', ':', '-'};

    //verificar espaco e pontuacao consecutivos
    //olhar a parte de pontuacao em sequencia
    for(int i=0; valor[i]!='\0'; i++){

        bool emPontuacao = 0;
        for(char c: pontuacao){
            if (c == valor[i]){
                emPontuacao = 1;
            }
        }
        if(isspace(valor[i]) && valor[i] == valor[i+1]){
            throw invalid_argument("Argumento invalido.");
        }
        else if(emPontuacao == 1 && valor[i] == valor[i+1]){
            throw invalid_argument("Argumento invalido.");
        }
    }


    //verificar caracteres
    for(int i=0; valor[i]!='\0'; i++){
        bool emPontuacao = 0;
        for(char c: pontuacao){
            if (c == valor[i]){
                emPontuacao = 1;
            }
        }
        if(isalpha(valor[i]) == 0 && isdigit(valor[i]) == 0 && isspace(valor[i]) == 0 && emPontuacao == 0){
            throw invalid_argument("Argumento invalido.");
           }
    }
}


void Nome::validar(string valor){

    //tamanho max 20 caracteres
    if(valor.size() > 20){
        throw invalid_argument("Argumento invalido.");
    }

    if(isupper(valor[0]) == 0){
        throw invalid_argument("Argumento invalido.");
    }

    //restante
    int qtdSobrenomes = 0;
    int separador = 0;

    for(int i=0; i<valor.size(); i++){
        if(isspace(valor[i]) == 0 && isalpha(valor[i]) == 0){
            throw invalid_argument("Argumento invalido.");
        }
        if(isspace(valor[i]) && valor[i+1]==valor[i]){
            throw invalid_argument("Argumento invalido.");
        }
        if(isspace(valor[i])){

            separador = i+1;
            qtdSobrenomes++;

            if(qtdSobrenomes > 2){
                throw invalid_argument("Argumento invalido.");
            }

            if(isupper(valor[separador]) == 0){
                throw invalid_argument("Argumento invalido.");
            }
        }
    }
    for(int i=0; i <valor.size(); i++){
        if(isspace(valor[i])){
            for(int k = i+2; valor[k] != ' ' && k < valor.size(); k++){
                if(islower(valor[k]) == 0){
                    throw invalid_argument("Argumento invalido.");
                }
            }
        }
    }
}



void Data::validar(string valor){


    //checar tamanho
    if(valor.size() != 8){
        throw invalid_argument("Argumento invalido.");
    }

    //ver se � bissexto:

    string fevereiro29 = string() + valor[0] + valor[1] + valor[3] + valor[4];

    if(fevereiro29 == "2902"){
        string ano = string() + valor[6] + valor[7];
        int anoInt;
        istringstream(ano) >> anoInt;
        anoInt += 2000;
        if((anoInt%400 == 0 || anoInt%100 != 0) && (anoInt%4 == 0)){
            ;
        }
        else{
            throw invalid_argument("Argumento invalido.");
        }


    }

    //checar formato
    else if(valor[2] != '-' || valor[5] != '-'){
        throw invalid_argument("Argumento invalido.");
    }

    string limiteDia = string() + valor[0] + valor[1];
    int limDia;
    istringstream(limiteDia) >> limDia;
    if( 1 > limDia || limDia > 31){
        throw invalid_argument("Argumento invalido.");
    }

    string limiteMes = string() + valor[3] + valor[4];
    int limMes;
    istringstream(limiteMes) >> limMes;
    if(1 > limMes || limMes > 12){
        throw invalid_argument("Argumento invalido.");
    }

    string limiteAno = string() + valor[6] + valor[7];
    int limAno;
    istringstream(limiteAno) >> limAno;
    if(0 > limAno || limAno > 99){
        throw invalid_argument("Argumento invalido.");
    }

}

void Disciplina::validar(string valor){

    string disciplinas[6] = {"Arquitetura", "Desenvolvimento", "Gerenciamento",
                    "Implantacao", "Requisitos", "Teste"};

    bool valorEsta = 0;
    for(string disciplina: disciplinas){
        if(valor == disciplina){
            valorEsta = 1;
            break;
        }
    }

    if(valorEsta == 0){
        throw invalid_argument("Argumento invalido");
    }

}

int Codigo::algoritmo_modulo_11(string numero){

    int soma = ((int)(numero[9])-48)*2 + ((int)(numero[8])-48)*3
               + ((int)(numero[7])-48)*4 + ((int)(numero[6])-48)*5
               + ((int)(numero[5])-48)*6 + ((int)(numero[4])-48)*7
               + ((int)(numero[3])-48)*8 + ((int)(numero[2])-48)*9
               + ((int)(numero[1])-48)*2 + ((int)(numero[0])-48)*3;

    int resto = (soma*10)%11;

    if (resto == 10){
        resto = 0;
    }

    return resto;
}

void Codigo::validar(string valor){

    //checar tamanho
    if(valor.size() != 11){
        throw invalid_argument("Argumento invalido.");
    };

    //checar formato
    for (int i=0; i<11; i++){
        if (isdigit(valor[i])==0){
            throw invalid_argument("Argumento invalido.");
        };
    };

    //checar d�gito verificador - algoritmo m�dulo 11
    if ((int)(valor[10])-48 != algoritmo_modulo_11(valor)){
        throw invalid_argument("Argumento invalido.");
    };

}


