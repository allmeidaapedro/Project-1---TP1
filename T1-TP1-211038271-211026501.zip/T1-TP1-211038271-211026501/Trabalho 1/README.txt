O trabalho aplica o paradigma de orientação a objetos na linguagem de programação c++.
A especificação do sistema e sua descrição constam no pdf da ementa "TP1-TRABALHO-1", de
senha "CIC0197UNB".

Para executar o projeto, proceda em um ambiente CodeBlocks, executando-o. Os resultados dos testes
de unidade serao exibidos. 

