#ifndef TESTES_H_INCLUDED
#define TESTES_H_INCLUDED

#include "Dominios.h"
#include "Entidades.h"


using namespace std;


//testes dominios


//matricula: 211038271
class TUSenha{
    private:
        const string VALOR_VALIDO = "PEDR70";
        const string VALOR_INVALIDO = "PEEDr1";
        Senha *senha;
        bool estado;
        void setUp();
        void tearDown();
        void testarCenarioSucesso();
        void testarCenarioFalha();
    public:
        bool run();
};


//matricula: 2110328271
class TUTexto{
    private:
        const string VALOR_VALIDO = "pEDro Lega1!090";
        const string VALOR_INVALIDO = "Pe d!ro1  !!";
        Texto *texto;
        bool estado;
        void setUp();
        void tearDown();
        void testarCenarioSucesso();
        void testarCenarioFalha();
    public:
        bool run();
};


//matricula: 211038271
class TUNome{
    private:
        const string VALOR_VALIDO = "Pedro H Almeida";
        const string VALOR_INVALIDO = "P H O ALmeida  ";
        Nome *nome;
        bool estado;
        void setUp();
        void tearDown();
        void testarCenarioSucesso();
        void testarCenarioFalha();
    public:
        bool run();
};


//matricula: 211038271
class TUData{
    private:
        const string VALOR_VALIDO = "30-11-22";
        const string VALOR_INVALIDO = "29-02/11";
        Data *data;
        bool estado;
        void setUp();
        void tearDown();
        void testarCenarioSucesso();
        void testarCenarioFalha();
    public:
        bool run();
};


//matricula: 211038271
class TUDisciplina{
    private:
        const string VALOR_VALIDO = "Arquitetura";
        const string VALOR_INVALIDO = "Calculo1";
        Disciplina *disciplina;
        bool estado;
        void setUp();
        void tearDown();
        void testarCenarioSucesso();
        void testarCenarioFalha();
    public:
        bool run();
};


//matricula 211026501
class TUMatricula{
    private:
        const string VALOR_VALIDO = "PUTZ2022";
        const string VALOR_INVALIDO = "211026501";
        Matricula *matricula;
        bool estado;
        void setUp();
        void tearDown();
        void testarCenarioSucesso();
        void testarCenarioFalha();
    public:
        bool run();
};


//matricula 211026501
class TUCodigo{
    private:
        const string VALOR_VALIDO = "21001221038";
        const string VALOR_INVALIDO = "21001221035";
        Codigo *codigo;
        bool estado;
        void setUp();
        void tearDown();
        void testarCenarioSucesso();
        void testarCenarioFalha();
    public:
        bool run();
};


//testes entidades


//matricula: 211038271
//Usuario: Nome, Matricula, Senha
class TUUsuario{
    private:
        const string VALOR_VALIDO_NOME = "Pedro Almeida";
        const string VALOR_VALIDO_MATRICULA = "PHAO2020";
        const string VALOR_VALIDO_SENHA = "PHAO19";
        Usuario *usuario;
        bool estado;
        void setUp();
        void tearDown();
        void testarCenarioSucesso();
    public:
        bool run();
};


//matricula: 211026501
class TUTarefa{
    private:
        const string VALOR_VALIDO_NOME = "Miguel Mendes 7";
        const string VALOR_VALIDO_INICIO = "03-04-93";
        const string VALOR_VALIDO_TERMINO = "02-02-94";
        const string VALOR_VALIDO_DISCIPLINA = "Arquitetura";
        const string VALOR_VALIDO_CODIGO = "21001221038";
        Tarefa *tarefa;
        bool estado;
        void setUp();
        void tearDown();
        void testarCenarioSucesso();
    public:
        bool run();
};


//matricula: 211026501
class TUProjeto{
    private:
        const string VALOR_VALIDO_NOME = "Pedro Almeida 30";
        const string VALOR_VALIDO_CODIGO = "21001221038";
        const string VALOR_VALIDO_DESCRICAO = "Jones Dionisio 27;";
        Projeto *projeto;
        bool estado;
        void setUp();
        void tearDown();
        void testarCenarioSucesso();
    public:
        bool run();
};

#endif
