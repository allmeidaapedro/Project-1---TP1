#include <iostream>
#include <algorithm>
#include "Dominios.h"
#include "Entidades.h"
#include "Testes.h"
#include <string>
#include <vector>
#include <sstream>
using namespace std;

int main()
{
    //testes dominios

    TUSenha testeSenha;
    if(testeSenha.run() == 0){
        cout << "SENHA N�O PASSOU NO TESTE" << endl;
    }
    else{
        cout << "SENHA PASSOU NO TESTE" << endl;
    }

    TUTexto testeTexto;
    if(testeTexto.run() == 0){
        cout << "TEXTO N�O PASSOU NO TESTE" << endl;
    }
    else{
        cout << "TEXTO PASSOU NO TESTE" << endl;
    }

    TUNome testeNome;
    if(testeNome.run() == 0){
        cout << "NOME FALHOU NO TESTE" << endl;
    }
    else{
        cout << "NOME PASSOU NO TESTE" << endl;
    }

    TUData testeData;
    if(testeData.run() == 0){
        cout << "DATA FALHOU NO TESTE" << endl;
    }
    else{
        cout << "DATA PASSOU NO TESTE" << endl;
    }


    TUDisciplina testeDisciplina;
    if(testeDisciplina.run() == 0){
        cout << "DISCIPLINA FALHOU NO TESTE" << endl;
    }
    else{
        cout << "DISCIPLINA PASSOU NO TESTE" << endl;
    }


    TUMatricula testeMatricula;
    if(testeMatricula.run() == 0){
        cout << "MATRICULA FALHOU NO TESTE" << endl;
    }
    else{
        cout << "MATRICULA PASSOU NO TESTE" << endl;
    }


    TUCodigo testeCodigo;
    if(testeCodigo.run() == 0){
        cout << "CODIGO FALHOU NO TESTE" << endl;
    }
    else{
        cout << "CODIGO PASSOU NO TESTE" << endl;
    }

    //testes entidades

    TUUsuario testeUsuario;
    if(testeUsuario.run() == 0){
        cout << "USUARIO FALHOU NO TESTE" << endl;
    }
    else{
        cout << "USUARIO PASSOU NO TESTE" << endl;
    }


    TUTarefa testeTarefa;
    if(testeTarefa.run() == 0){
        cout << "TAREFA FALHOU NO TESTE" << endl;
    }
    else{
        cout << "TAREFA PASSOU NO TESTE" << endl;
    }


    TUProjeto testeProjeto;
    if(testeProjeto.run() == 0){
        cout << "PROJETO FALHOU NO TESTE" << endl;
    }
    else{
        cout << "PROJETO PASSOU NO TESTE" << endl;
    }


    return 0;
}

