#ifndef ENTIDADES_H_INCLUDED
#define ENTIDADES_H_INCLUDED

#include "Dominios.h"


///Servi&ccedil;o de menor complexidade a ser executado no escopo de um projeto que, por sua vez, est&aacute; associado
///a um usu&aacute;rio.

//matricula: 211026501
class Tarefa {
    private:
        Texto nome;
        Codigo codigo;
        Data inicio;
        Data termino;
        Disciplina disciplina;
    public:

        /// Atribui uma inst&acirc;ncia de Texto ao atributo nome da Tarefa.
        ///
        /// @param const Texto& - passagem de par&acirc;metro constante por refer&ecirc;ncia para objeto da classe Texto.

        void setNome(const Texto&);

        /// Retorna nome.
        ///
        /// @return nome - inst&acirc;ncia da classe Texto.

        Texto getNome() const;

        /// Atribui uma inst&acirc;ncia de Codigo ao atributo codigo da Tarefa.
        ///
        /// @param const Codigo& - passagem de par&acirc;metro constante por refer&ecirc;ncia para objeto da classe Codigo.

        void setCodigo(const Codigo&);

        /// Retorna codigo.
        ///
        /// @return codigo - inst&acirc;ncia da classe Codigo.

        Codigo getCodigo() const;

        /// Atribui uma inst&acirc;ncia de Data ao atributo inicio da Tarefa.
        ///
        /// @param const Data& - passagem de par&acirc;metro constante por refer&ecirc;ncia para objeto da classe Data.

        void setInicio(const Data&);

        /// Retorna inicio.
        ///
        /// @return inicio - inst&acirc;ncia da classe Data.

        Data getInicio() const;

        /// Atribui uma inst&acirc;ncia de Data ao atributo termino da Tarefa.
        ///
        /// @param const Data& - passagem de par&acirc;metro constante por refer&ecirc;ncia para objeto da classe Data.

        void setTermino(const Data&);

        /// Retorna termino.
        ///
        /// @return termino - inst&acirc;ncia da classe Data.

        Data getTermino() const;

        /// Atribui uma inst&acirc;ncia de Disciplina ao atributo disciplina da Tarefa.
        ///
        /// @param const Disciplina& - passagem de par&acirc;metro constante por refer&ecirc;ncia para objeto da classe Disciplina.

        void setDisciplina(const Disciplina&);

        /// Retorna disciplina.
        ///
        /// @return disciplina - inst&acirc;ncia da classe Disciplina.

        Disciplina getDisciplina() const;

};

inline void Tarefa::setNome(const Texto& nome){
    this->nome = nome;
}

inline Texto Tarefa::getNome() const {
    return nome;
}

inline void Tarefa::setCodigo(const Codigo& codigo){
    this->codigo = codigo;
}

inline Codigo Tarefa::getCodigo() const {
    return codigo;
}

inline void Tarefa::setInicio(const Data& inicio){
    this->inicio = inicio;
}

inline Data Tarefa::getInicio() const {
    return inicio;
}

inline void Tarefa::setTermino(const Data& termino){
    this->termino = termino;
}

inline Data Tarefa::getTermino() const {
    return termino;
}

inline void Tarefa::setDisciplina(const Disciplina& disciplina){
    this->disciplina = disciplina;
}

inline Disciplina Tarefa::getDisciplina() const{
    return disciplina;
};


///Agrupamento de tarefas a serem realizadas por um usu&aacute;rio.

//matricula: 211026501
class Projeto {
    private:
        Texto nome;
        Texto descricao;
        Codigo codigo;
    public:

        /// Atribui uma inst&acirc;ncia de Texto ao atributo nome do Projeto.
        ///
        /// @param const Texto& - passagem de par&acirc;metro constante por refer&ecirc;ncia para objeto da classe Texto.

        void setNome(const Texto&);

        /// Retorna nome.
        ///
        /// @return nome - inst&acirc;ncia da classe Texto.

        Texto getNome() const;

        /// Atribui uma inst&acirc;ncia de Texto ao atributo descricao do Projeto.
        ///
        /// @param const Texto& - passagem de par&acirc;metro constante por refer&ecirc;ncia para objeto da classe Texto.

        void setDescricao(const Texto&);

        /// Retorna descricao.
        ///
        /// @return descricao - inst&acirc;ncia da classe Texto.

        Texto getDescricao() const;

        /// Atribui uma inst&acirc;ncia de Codigo ao atributo codigo do Projeto.
        ///
        /// @param const Codigo& - passagem de par&acirc;metro constante por refer&ecirc;ncia para objeto da classe Codigo.

        void setCodigo(const Codigo&);

        /// Retorna codigo.
        ///
        /// @return codigo - inst&acirc;ncia da classe Codigo.

        Codigo getCodigo() const;

};

inline void Projeto::setNome(const Texto& nome){
    this->nome = nome;
}

inline Texto Projeto::getNome() const{
    return nome;
}

inline void Projeto::setDescricao(const Texto& descricao){
    this->descricao = descricao;
}

inline Texto Projeto::getDescricao() const{
    return descricao;
}

inline void Projeto::setCodigo(const Codigo& codigo){
    this->codigo = codigo;
}

inline Codigo Projeto::getCodigo() const{
    return codigo;
};


/// Entidade que pode visualizar, cadastrar, editar e descadastrar projeto e tarefa associados, al&eacute;m de visualizar,
/// cadastrar, editar (exceto matr&iacute;cula) e descadastrar a si mesma, utilizando inst&acirc;ncias das classes de dom&iacute;nios.

//matricula: 211038271
class Usuario {
    private:
        Nome nome;
        Matricula matricula;
        Senha senha;
    public:

        /// Atribui uma inst&acirc;ncia de Nome ao atributo nome de Usuario.
        ///
        /// @param const Nome& - passagem de par&acirc;metro constante por refer&ecirc;ncia para objeto da classe Nome.

        void setNome(const Nome&);

        /// Retorna nome.
        ///
        /// @return nome - inst&acirc;ncia da classe Nome.

        Nome getNome() const;

        /// Atribui uma inst&acirc;ncia de Matricula ao atributo matricula de Usuario.
        ///
        /// @param const Matricula& - passagem de par&acirc;metro constante por refer&ecirc;ncia para objeto da classe Matricula.

        void setMatricula(const Matricula&);

        /// Retorna matricula.
        ///
        /// @return matricula - inst&acirc;ncia da classe Matricula.

        Matricula getMatricula() const;

        /// Atribui uma inst&acirc;ncia de Senha ao atributo senha de Usuario.
        ///
        /// @param const Senha& - passagem de par&acirc;metro constante por refer&ecirc;ncia para objeto da classe Senha.

        void setSenha(const Senha&);

        /// Retorna senha.
        ///
        /// @return senha - inst&acirc;ncia da classe Senha.

        Senha getSenha() const;

};

inline void Usuario::setNome(const Nome& nome){
    this->nome = nome;
}

inline Nome Usuario::getNome() const{
    return nome;
}

inline void Usuario::setMatricula(const Matricula& matricula){
    this->matricula = matricula;
}

inline Matricula Usuario::getMatricula() const{
    return matricula;
}

inline void Usuario::setSenha(const Senha& senha){
    this->senha = senha;
}

inline Senha Usuario::getSenha() const{
    return senha;
}

#endif
