#ifndef DOMINIOS_H_INCLUDED
#define DOMINIOS_H_INCLUDED

#include <stdexcept>

using namespace std;

/// Classe base para heran&ccedil;a de cada dom&iacute;nio.

//matricula: 211038271
class Dominio{
    private:
        string valor;
    protected:

        /// Abstrato, checar&aacute;, para cada dom&iacute;nio, se o valor atende ou n&atilde;o ao formato espec&iacute;fico.
        ///
        /// @param valor - string a checar formato
        ///
        /// @throw invalid_argument - Argumento inv&aacute;lido, caso valor n&atilde;o atenda ao formato.

        virtual void validar(string) = 0;
    public:

        /// Armazena, "seta" o valor no respectivo dom&iacute;nio, caso ele seja v&aacute;lido.
        ///
        /// @param valor

        void setValor(string);
        string getValor() const;
};

/// Retorna valor.
///
/// @return valor

inline string Dominio::getValor() const{
    return valor;
}


///N&uacute;mero que representa a inscri&ccedil;&atilde;o no &oacute;rg&atilde;o ou sistema.
///
///Regras de formato:
/// - Matr&iacute;cula &eacute; composta por 8 caracteres.
/// - Os quatro primeiros caracteres s&atilde;o letras mai&uacute;sculas (A-Z).
/// - Os quatro caracteres finais s&atilde;o d&iacute;gitos (0-9).
///
///@throw invalid_argument - valor checado inv&aacute;lido.

//matricula: 211026501
class Matricula:public Dominio{
    private:
        string valor;
        void validar(string);
};


/// Representa palavra secreta, que deseja-se esconder.
///
/// Regras de formato:
/// - 6 caracteres.
/// - Cada caractere X &eacute; letra mai&uacute;scula (A-Z) ou d&iacute;gito (0-9)
/// - N&atilde;o pode haver caractere duplicado.
/// - Existem pelo menos duas letras mai&uacute;sculas e dois d&iacute;gitos.
///
/// @throw invalid_argument - valor checado inv&aacute;lido.

//matricula: 211038271
class Senha:public Dominio{
    private:
        string valor;
        void validar(string);
};


/// Conjunto organizado de palavras e relacionados.
///
/// Regras de formato:
/// - 10 a 40 caracteres.
/// - Cada caractere X &eacute; letra (A-Z ou a-z), d&iacute;gito (0-9) ou sinal de pontua&ccedil;&atilde;o ( . , ; ? ! : - ).
/// - N&atilde;o h&aacute; espa&ccedil;os em branco em sequ&ecirc;ncia.
/// - N&atilde;o h&aacute; sinal de pontua&ccedil;&atilde;o (. , ; : ? ! -) em sequ&ecirc;ncia.
/// - Acentua&ccedil;&atilde;o pode ser desconsiderada.
///
/// @throw invalid_argument - valor checado inv&aacute;lido.

//matricula: 211038271
class Texto:public Dominio{
    private:
        string valor;
        void validar(string);
};


/// Denomina&ccedil;&atilde;o; palavra ou express&atilde;o que designa algo ou algu&eacute;m.
///
/// Regras de formato:
/// - Nome &eacute; composto por prenome e at&eacute; dois sobrenomes.
/// - Texto (prenome mais sobrenomes e espa&ccedil;os em branco) &eacute; composto por total de at&eacute; 20 caracteres.
/// - Cada caractere &eacute; letra (A-Z a-z) ou espa&ccedil;o em branco.
/// - Primeira letra de prenome ou de sobrenome &eacute; mai&uacute;scula (A-Z) e as outras s&atilde;o min&uacute;sculas (a-z).
/// - N&atilde;o h&aacute; espa&ccedil;os em branco em sequ&ecirc;ncia.
/// - Acentua&ccedil;&atilde;o pode ser desconsiderada.
///
/// @throw invalid_argument - valor checado inv&aacute;lido.

//matricula: 211038271
class Nome:public Dominio{
    private:
        string valor;
        void validar(string);
};


/// Indica&ccedil;&atilde;o do dia, do m&ecirc;s e do ano.
///
/// Regras de formato:
/// - Formato DD-MES-ANO
/// - DD - 01 a 31
/// - MES - 01 a 12
/// - ANO - 00 a 99
/// - Deve ser levado em considera&ccedil;&atilde;o se ano &eacute; ou n&atilde;o &eacute; bissexto.
///
/// @throw invalid_argument - valor checado inv&aacute;lido.

//matricula: 211038271
class Data:public Dominio{
    private:
        string valor;
        void validar(string);
};


///&Aacute;rea de conhecimento espec&iacute;fica agrupada por elementos de aprendizado relacionados.
///
///Regras de formato:
/// - Disciplina &eacute; uma palavra dentre as a seguir: Arquitetura, Desenvolvimento, Gerenciamento, Implantacao, Requisitos, Teste.
///
///@throw invalid_argument - valor checado inv&aacute;lido.

//matricula: 211026501
class Disciplina:public Dominio{
    private:
        string valor;
        void validar(string);
};


///Sequ&ecirc;ncia de onze d&iacute;gitos, em que o &uacute;ltimo d&iacute;gito &eacute; o d&iacute;gito verificador.
///
///Regras de formato:
/// - C&oacute;digo &eacute; formado por 11 d&iacute;gitos (0-9).
/// - O &uacute;ltimo d&iacute;gito &eacute; o d&iacute;gito verificador, calculado atrav&eacute;s do algoritmo m&oacute;dulo 11.
///
///@throw invalid_argument - valor checado inv&aacute;lido.

//matricula: 211026501
class Codigo:public Dominio{
    private:
        string valor;
        void validar(string);
        int algoritmo_modulo_11(string);
};


#endif
