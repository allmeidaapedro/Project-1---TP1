#include "Testes.h"

using namespace std;
#include <iostream>



void TUSenha::setUp(){
    senha = new Senha();
    estado = true;
}


void TUSenha::tearDown(){
    delete senha;
}


void TUSenha::testarCenarioSucesso(){
    try{
        senha->setValor(VALOR_VALIDO);
        if(senha->getValor() != VALOR_VALIDO){
            estado = false;
        }
    }
    catch(invalid_argument &excecao){
        estado = false;
    }

}


void TUSenha::testarCenarioFalha(){
    try{
        senha->setValor(VALOR_INVALIDO);
        estado = false;
    }
    catch(invalid_argument &excecao){
        if(senha->getValor() == VALOR_INVALIDO){
            estado = false;
        }
    }
}

bool TUSenha::run(){
    setUp();
    testarCenarioSucesso();
    testarCenarioFalha();
    tearDown();
    return estado;
}


void TUTexto::setUp(){
    texto = new Texto;
    estado = true;
}


void TUTexto::tearDown(){
    delete texto;
}


void TUTexto::testarCenarioSucesso(){
    try{
        texto->setValor(VALOR_VALIDO);
        if(texto->getValor() != VALOR_VALIDO){
            estado = false;
        }
    }
    catch(invalid_argument &excecao){
        estado = false;
    }
}


void TUTexto::testarCenarioFalha(){
    try{
        texto->setValor(VALOR_INVALIDO);
        estado = false;
    }
    catch(invalid_argument &excecao){
        if(texto->getValor() == VALOR_INVALIDO){
            estado = false;
        }
    }
}


bool TUTexto::run(){
    setUp();
    testarCenarioSucesso();
    testarCenarioFalha();
    tearDown();
    return estado;
}


void TUNome::setUp(){
    nome = new Nome;
    estado = true;
}


void TUNome::tearDown(){
    delete nome;
}


void TUNome::testarCenarioSucesso(){
    try{
        nome->setValor(VALOR_VALIDO);
        if(nome->getValor() != VALOR_VALIDO){
            estado = false;
        }
    }
    catch(invalid_argument &excecao){
        estado = false;
    }
}


void TUNome::testarCenarioFalha(){
    try{
        nome->setValor(VALOR_INVALIDO);
        estado = false;
    }
    catch(invalid_argument &excecao){
        if(nome->getValor() == VALOR_INVALIDO){
            estado = false;
        }
    }
}


bool TUNome::run(){
    setUp();
    testarCenarioSucesso();
    testarCenarioFalha();
    tearDown();
    return estado;
}


void TUData::setUp(){
    data = new Data;
    estado = true;
}


void TUData::tearDown(){
    delete data;
}


void TUData::testarCenarioSucesso(){
    try{
        data->setValor(VALOR_VALIDO);
        if(data->getValor() != VALOR_VALIDO){
            estado = false;
        }
    }
    catch(invalid_argument &excecao){
        estado = false;
    }
}


void TUData::testarCenarioFalha(){
    try{
        data->setValor(VALOR_INVALIDO);
        estado = false;
    }
    catch(invalid_argument &excecao){
        if(data->getValor() == VALOR_INVALIDO){
            estado = false;
        }
    }
}


bool TUData::run(){
    setUp();
    testarCenarioSucesso();
    testarCenarioFalha();
    tearDown();
    return estado;
}


void TUDisciplina::setUp(){
    disciplina = new Disciplina();
    estado = true;
}


void TUDisciplina::tearDown(){
    delete disciplina;
}


void TUDisciplina::testarCenarioSucesso(){
    try{
        disciplina->setValor(VALOR_VALIDO);
        if(disciplina->getValor() != VALOR_VALIDO){
            estado = false;
        }
    }
    catch(invalid_argument &excecao){
        estado = false;
    }
}


void TUDisciplina::testarCenarioFalha(){
    try{
        disciplina->setValor(VALOR_INVALIDO);
        estado = false;
    }
    catch(invalid_argument &excecao){
        if(disciplina->getValor() == VALOR_INVALIDO){
            estado = false;
        }
    }
}


bool TUDisciplina::run(){
    setUp();
    testarCenarioSucesso();
    testarCenarioFalha();
    tearDown();
    return estado;
}


void TUMatricula::setUp(){
    matricula = new Matricula();
    estado = true;
}


void TUMatricula::tearDown(){
    delete matricula;
}


void TUMatricula::testarCenarioSucesso(){
    try{
        matricula->setValor(VALOR_VALIDO);
        if(matricula->getValor() != VALOR_VALIDO){
            estado = false;
        }
    }
    catch(invalid_argument &excecao){
        estado = false;
    }

}


void TUMatricula::testarCenarioFalha(){
    try{
        matricula->setValor(VALOR_INVALIDO);
        estado = false;
    }
    catch(invalid_argument &excecao){
        if(matricula->getValor() == VALOR_INVALIDO){
            estado = false;
        }
    }
}


bool TUMatricula::run(){
    setUp();
    testarCenarioSucesso();
    testarCenarioFalha();
    tearDown();
    return estado;
}


void TUCodigo::setUp(){
    codigo = new Codigo();
    estado = true;
}


void TUCodigo::tearDown(){
    delete codigo;
}


void TUCodigo::testarCenarioSucesso(){
    try{
        codigo->setValor(VALOR_VALIDO);
        if(codigo->getValor() != VALOR_VALIDO){
            estado = false;
        }
    }
    catch(invalid_argument &excecao){
        estado = false;
    }

}


void TUCodigo::testarCenarioFalha(){
    try{
        codigo->setValor(VALOR_INVALIDO);
        estado = false;
    }
    catch(invalid_argument &excecao){
        if(codigo->getValor() == VALOR_INVALIDO){
            estado = false;
        }
    }
}


bool TUCodigo::run(){
    setUp();
    testarCenarioSucesso();
    testarCenarioFalha();
    tearDown();
    return estado;
}


bool TUUsuario::run(){
    setUp();
    testarCenarioSucesso();
    tearDown();
    return estado;
}



void TUUsuario::setUp(){
    usuario = new Usuario;
    estado = true;
}


void TUUsuario::tearDown(){
    delete usuario;
}

void TUUsuario::testarCenarioSucesso(){
   Matricula matricula;
   matricula.setValor(VALOR_VALIDO_MATRICULA);
   usuario->setMatricula(matricula);
   if(usuario->getMatricula().getValor() != VALOR_VALIDO_MATRICULA)
        estado = false;

   Nome nome;
   nome.setValor(VALOR_VALIDO_NOME);
   usuario->setNome(nome);
   if(usuario->getNome().getValor() != VALOR_VALIDO_NOME)
        estado = false;

  Senha senha;
  senha.setValor(VALOR_VALIDO_SENHA);
  usuario->setSenha(senha);
  if(usuario->getSenha().getValor() != VALOR_VALIDO_SENHA)
    estado = false;

}


bool TUTarefa::run(){
    setUp();
    testarCenarioSucesso();
    tearDown();
    return estado;
}



void TUTarefa::setUp(){
    tarefa = new Tarefa;
    estado = true;
}


void TUTarefa::tearDown(){
    delete tarefa;
}

void TUTarefa::testarCenarioSucesso(){
   Texto nome;
   nome.setValor(VALOR_VALIDO_NOME);
   tarefa->setNome(nome);
   if(tarefa->getNome().getValor() != VALOR_VALIDO_NOME)
        estado = false;

   Data inicio;
   inicio.setValor(VALOR_VALIDO_INICIO);
   tarefa->setInicio(inicio);
   if(tarefa->getInicio().getValor() != VALOR_VALIDO_INICIO)
        estado = false;

  Data termino;
  termino.setValor(VALOR_VALIDO_TERMINO);
  tarefa->setTermino(termino);
  if(tarefa->getTermino().getValor() != VALOR_VALIDO_TERMINO)
    estado = false;

  Codigo codigo;
  codigo.setValor(VALOR_VALIDO_CODIGO);
  tarefa->setCodigo(codigo);
  if(tarefa->getCodigo().getValor() != VALOR_VALIDO_CODIGO)
    estado = false;

}


bool TUProjeto::run(){
    setUp();
    testarCenarioSucesso();
    tearDown();
    return estado;
}



void TUProjeto::setUp(){
    projeto = new Projeto;
    estado = true;
}


void TUProjeto::tearDown(){
    delete projeto;
}

void TUProjeto::testarCenarioSucesso(){
   Texto nome;
   nome.setValor(VALOR_VALIDO_NOME);
   projeto->setNome(nome);
   if(projeto->getNome().getValor() != VALOR_VALIDO_NOME)
    estado = false;

  Codigo codigo;
  codigo.setValor(VALOR_VALIDO_CODIGO);
  projeto->setCodigo(codigo);
  if(projeto->getCodigo().getValor() != VALOR_VALIDO_CODIGO)
    estado = false;

  Texto descricao;
  descricao.setValor(VALOR_VALIDO_DESCRICAO);
  projeto->setDescricao(descricao);
  if(projeto->getDescricao().getValor() != VALOR_VALIDO_DESCRICAO)
    estado = false;

}
